﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class RegForm : Form
    {
        public RegForm()
        {
            InitializeComponent();
        }

        private void CheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (CheckBox.Checked == true)
            {
                EnterBtn.Enabled = true;
            }
            else { EnterBtn.Enabled = false; }
        }

        private void EnterBtn_Click(object sender, EventArgs e)
        {
            if (InputLogin.Text != " " || InputLogin.Text != "Логин" || InputLogin.Text != "" || InputPassword.Text != "Пароль" || InputPassword.Text != " " || InputPassword.Text != "" || InputName.Text != " " || InputName.Text != "" || InputName.Text != "Имя" || InputSurname.Text != " " || InputSurname.Text != "" || InputSurname.Text != "Фамилия" || InputPantynomic.Text != "" || InputPantynomic.Text != " " || InputPantynomic.Text != "Отчество")
            {
                DB db = new DB();
                MySqlCommand command = new MySqlCommand("INSERT INTO `user`(`UserName`, `UserSurname`, `UserPatronymic`, `UserLogin`, `UserPassword`, `UserRole`) VALUES (@UserName, @UserSurname, @UserPatronymic, @UserLogin, @UserPassword, '1' )", db.GetConnection());

                command.Parameters.Add("@UserName", MySqlDbType.VarChar).Value = InputName.Text;
                command.Parameters.Add("@UserSurname", MySqlDbType.VarChar).Value = InputSurname.Text;
                command.Parameters.Add("@UserPatronymic", MySqlDbType.VarChar).Value = InputPantynomic.Text;
                command.Parameters.Add("@UserLogin", MySqlDbType.VarChar).Value = InputLogin.Text;
                command.Parameters.Add("@UserPassword", MySqlDbType.VarChar).Value = InputPassword.Text;

                db.openConnection();
                if (command.ExecuteNonQuery() != 0)
                {
                    MessageBox.Show("Аккаунт был успешно создан");
                }
                else
                {
                    MessageBox.Show("Аккаунт не был создан");
                }
            }
            else
            {
                MessageBox.Show("Введите свои данные");
            }
        }
    }
}
