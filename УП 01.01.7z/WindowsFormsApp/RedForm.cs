﻿using MySql.Data.MySqlClient;
using MySqlX.XDevAPI.Relational;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class RedForm : Form
    {
        DB db = new DB();
        DataTable table = new DataTable();
        MySqlDataAdapter adapter = new MySqlDataAdapter();
        public RedForm()
        {
            InitializeComponent();
            MySqlCommand command = new MySqlCommand("SELECT * FROM `product`", db.GetConnection());
            adapter.SelectCommand = command;
            adapter.Fill(table);
        }

        private void RedForm_Load(object sender, EventArgs e)
        {

        }

        private void ButtonAdd_Click(object sender, EventArgs e)
        {
            MySqlCommand command = new MySqlCommand("INSERT INTO `product` (`ProductPhoto`) VALUES ( @ProductPhoto, );", db.GetConnection());
            command.Parameters.Add("@ProductPhoto", MySqlDbType.VarChar).Value = namePhoto.Text;
            if (checkProduct())
            {
                return;
            }
            else if (string.IsNullOrEmpty(Article.Text) || string.IsNullOrEmpty(NameProduct.Text) || string.IsNullOrEmpty(Discription.Text) || string.IsNullOrEmpty(Category.Text)
            || string.IsNullOrEmpty(Manif.Text) || string.IsNullOrEmpty(Price.Text) || string.IsNullOrEmpty(Discount.Text) || string.IsNullOrEmpty(Qiantity.Text)
            || string.IsNullOrEmpty(MaxDiscount.Text) || string.IsNullOrEmpty(Suplier.Text))
            {
                MessageBox.Show("Не все поля заполнены");
                return;
            }
            DataRow row = table.NewRow();
            string Manifacture = "";
            string Supplier = "";
            string Categories = "";
            string Ed = "";
            if (Manif.Text == "БТК Текстиль") { Manifacture = "1"; }
            else if (Manif.Text == "Комильфо") { Manifacture = "2"; }
            else if (Manif.Text == "Май Фабрик") { Manifacture = "3"; }
            else if (Manif.Text == "Империя ткани") { Manifacture = "4"; }

            if (Suplier.Text == "Раута") { Supplier = "1"; }
            else if (Suplier.Text == "ООО Афо-Тек") { Supplier = "2"; }
            else if (Suplier.Text == "ГК Петров") { Supplier = "3"; }

            if (Category.Text == "Постельные ткани") { Categories = "1"; }
            else if (Category.Text == "Детские ткани") { Categories = "2"; }
            else if (Category.Text == "Ткани для изделий") { Categories = "3"; }

            if (Edizm.Text == "Рулоны") { Ed = "1"; }


            row["ProductArticleNumber"] = Article.Text;
            row["ProductName"] = NameProduct.Text;
            row["ProductDescription"] = Discription.Text;
            row["ProductCategory"] = Convert.ToInt32(Categories);
            row["ProductManufacturer"] = Convert.ToInt32(Manifacture);
            row["ProductCost"] = Price.Text;
            row["ProductDiscountAmount"] = Discount.Text;
            row["ProductQuantityInStock"] = Qiantity.Text;
            row["ProductCurrentDiscount"] = MaxDiscount.Text;
            row["ProductProvider"] = Convert.ToInt32(Supplier);
            row["ProductUnit"] = Convert.ToInt32(Ed);



            table.Rows.Add(row);
            MySqlCommandBuilder cb = new MySqlCommandBuilder(adapter);
            adapter.Update(table);
            table.Clear();
            adapter.Fill(table);
            DialogResult result = MessageBox.Show("Товар успешно добавлен", "Добавление",
            MessageBoxButtons.OK);

            foreach (Control ctrl in Controls)
            {
                if (ctrl is TextBox)
                {
                    ((TextBox)ctrl).Clear();
                }
            }

            this.Close();
            AdminForm form = new AdminForm();
        }
        public Boolean checkProduct()
        {
            DB dB = new DB();
            DataTable dataTable = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter();
            if (dataTable.Rows.Count > 0)
            {
                MessageBox.Show("Такой товар уже существует.");
                return true;

            }
            else
            {
                return false;
            }
        }
        private void ImportPhoto_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog();// создаем диалоговое окно
            openFile.ShowDialog();// открываем окно
            string FileName = openFile.FileName;// берем полный адрес картинки            
            namePhoto.ImageLocation = FileName;// грузим картинку в pictureBox
            namePhoto.Text = FileName;
        }

        private void Close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ImportPhoto_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog();// создаем диалоговое окно
            openFile.ShowDialog();// открываем окно
            string FileName = openFile.FileName;// берем полный адрес картинки            
            namePhoto.ImageLocation = FileName;// грузим картинку в pictureBox
            namePhoto.Text = FileName;
        }
    }
}
