﻿namespace WindowsFormsApp1
{
    partial class RedForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RedForm));
            this.CloseBtn = new System.Windows.Forms.Button();
            this.ButtonAdd = new System.Windows.Forms.Button();
            this.Edizm = new System.Windows.Forms.ComboBox();
            this.Category = new System.Windows.Forms.ComboBox();
            this.Suplier = new System.Windows.Forms.ComboBox();
            this.Manif = new System.Windows.Forms.ComboBox();
            this.ImportPhoto = new System.Windows.Forms.Button();
            this.namePhoto = new System.Windows.Forms.PictureBox();
            this.Qiantity = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.MaxDiscount = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Discount = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Price = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Cat = new System.Windows.Forms.Label();
            this.Discription = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.NameProduct = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Article = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.namePhoto)).BeginInit();
            this.SuspendLayout();
            // 
            // CloseBtn
            // 
            this.CloseBtn.BackColor = System.Drawing.Color.White;
            this.CloseBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CloseBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(140)))), ((int)(((byte)(81)))));
            this.CloseBtn.FlatAppearance.BorderSize = 2;
            this.CloseBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(140)))), ((int)(((byte)(81)))));
            this.CloseBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(140)))), ((int)(((byte)(81)))));
            resources.ApplyResources(this.CloseBtn, "CloseBtn");
            this.CloseBtn.ForeColor = System.Drawing.Color.YellowGreen;
            this.CloseBtn.Name = "CloseBtn";
            this.CloseBtn.UseVisualStyleBackColor = false;
            // 
            // ButtonAdd
            // 
            this.ButtonAdd.BackColor = System.Drawing.Color.White;
            this.ButtonAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonAdd.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(140)))), ((int)(((byte)(81)))));
            this.ButtonAdd.FlatAppearance.BorderSize = 2;
            this.ButtonAdd.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(140)))), ((int)(((byte)(81)))));
            this.ButtonAdd.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(140)))), ((int)(((byte)(81)))));
            resources.ApplyResources(this.ButtonAdd, "ButtonAdd");
            this.ButtonAdd.ForeColor = System.Drawing.Color.YellowGreen;
            this.ButtonAdd.Name = "ButtonAdd";
            this.ButtonAdd.UseVisualStyleBackColor = false;
            this.ButtonAdd.Click += new System.EventHandler(this.ButtonAdd_Click);
            // 
            // Edizm
            // 
            resources.ApplyResources(this.Edizm, "Edizm");
            this.Edizm.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(140)))), ((int)(((byte)(81)))));
            this.Edizm.FormattingEnabled = true;
            this.Edizm.Items.AddRange(new object[] {
            resources.GetString("Edizm.Items")});
            this.Edizm.Name = "Edizm";
            // 
            // Category
            // 
            resources.ApplyResources(this.Category, "Category");
            this.Category.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(140)))), ((int)(((byte)(81)))));
            this.Category.FormattingEnabled = true;
            this.Category.Items.AddRange(new object[] {
            resources.GetString("Category.Items"),
            resources.GetString("Category.Items1"),
            resources.GetString("Category.Items2")});
            this.Category.Name = "Category";
            // 
            // Suplier
            // 
            resources.ApplyResources(this.Suplier, "Suplier");
            this.Suplier.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(140)))), ((int)(((byte)(81)))));
            this.Suplier.FormattingEnabled = true;
            this.Suplier.Items.AddRange(new object[] {
            resources.GetString("Suplier.Items"),
            resources.GetString("Suplier.Items1"),
            resources.GetString("Suplier.Items2")});
            this.Suplier.Name = "Suplier";
            // 
            // Manif
            // 
            resources.ApplyResources(this.Manif, "Manif");
            this.Manif.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(140)))), ((int)(((byte)(81)))));
            this.Manif.FormattingEnabled = true;
            this.Manif.Items.AddRange(new object[] {
            resources.GetString("Manif.Items"),
            resources.GetString("Manif.Items1"),
            resources.GetString("Manif.Items2"),
            resources.GetString("Manif.Items3")});
            this.Manif.Name = "Manif";
            // 
            // ImportPhoto
            // 
            resources.ApplyResources(this.ImportPhoto, "ImportPhoto");
            this.ImportPhoto.ForeColor = System.Drawing.Color.YellowGreen;
            this.ImportPhoto.Name = "ImportPhoto";
            this.ImportPhoto.UseVisualStyleBackColor = true;
            this.ImportPhoto.Click += new System.EventHandler(this.ImportPhoto_Click_1);
            // 
            // namePhoto
            // 
            resources.ApplyResources(this.namePhoto, "namePhoto");
            this.namePhoto.Name = "namePhoto";
            this.namePhoto.TabStop = false;
            // 
            // Qiantity
            // 
            resources.ApplyResources(this.Qiantity, "Qiantity");
            this.Qiantity.Name = "Qiantity";
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.ForeColor = System.Drawing.Color.YellowGreen;
            this.label11.Name = "label11";
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.ForeColor = System.Drawing.Color.YellowGreen;
            this.label10.Name = "label10";
            // 
            // MaxDiscount
            // 
            resources.ApplyResources(this.MaxDiscount, "MaxDiscount");
            this.MaxDiscount.Name = "MaxDiscount";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.ForeColor = System.Drawing.Color.YellowGreen;
            this.label8.Name = "label8";
            // 
            // Discount
            // 
            resources.ApplyResources(this.Discount, "Discount");
            this.Discount.Name = "Discount";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.ForeColor = System.Drawing.Color.YellowGreen;
            this.label7.Name = "label7";
            // 
            // Price
            // 
            resources.ApplyResources(this.Price, "Price");
            this.Price.Name = "Price";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.ForeColor = System.Drawing.Color.YellowGreen;
            this.label6.Name = "label6";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.ForeColor = System.Drawing.Color.YellowGreen;
            this.label5.Name = "label5";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.ForeColor = System.Drawing.Color.YellowGreen;
            this.label4.Name = "label4";
            // 
            // Cat
            // 
            resources.ApplyResources(this.Cat, "Cat");
            this.Cat.ForeColor = System.Drawing.Color.YellowGreen;
            this.Cat.Name = "Cat";
            // 
            // Discription
            // 
            resources.ApplyResources(this.Discription, "Discription");
            this.Discription.Name = "Discription";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.ForeColor = System.Drawing.Color.YellowGreen;
            this.label3.Name = "label3";
            // 
            // NameProduct
            // 
            resources.ApplyResources(this.NameProduct, "NameProduct");
            this.NameProduct.Name = "NameProduct";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.ForeColor = System.Drawing.Color.YellowGreen;
            this.label2.Name = "label2";
            // 
            // Article
            // 
            resources.ApplyResources(this.Article, "Article");
            this.Article.Name = "Article";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.Color.YellowGreen;
            this.label1.Name = "label1";
            // 
            // RedForm
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.CloseBtn);
            this.Controls.Add(this.ButtonAdd);
            this.Controls.Add(this.Edizm);
            this.Controls.Add(this.Category);
            this.Controls.Add(this.Suplier);
            this.Controls.Add(this.Manif);
            this.Controls.Add(this.ImportPhoto);
            this.Controls.Add(this.namePhoto);
            this.Controls.Add(this.Qiantity);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.MaxDiscount);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.Discount);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Price);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Cat);
            this.Controls.Add(this.Discription);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.NameProduct);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Article);
            this.Controls.Add(this.label1);
            this.Name = "RedForm";
            this.Load += new System.EventHandler(this.RedForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.namePhoto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button CloseBtn;
        private System.Windows.Forms.Button ButtonAdd;
        private System.Windows.Forms.ComboBox Edizm;
        private System.Windows.Forms.ComboBox Category;
        private System.Windows.Forms.ComboBox Suplier;
        private System.Windows.Forms.ComboBox Manif;
        private System.Windows.Forms.Button ImportPhoto;
        private System.Windows.Forms.PictureBox namePhoto;
        private System.Windows.Forms.TextBox Qiantity;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox MaxDiscount;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox Discount;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox Price;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label Cat;
        private System.Windows.Forms.TextBox Discription;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox NameProduct;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Article;
        private System.Windows.Forms.Label label1;
    }
}