﻿using MySql.Data.MySqlClient;
using Mysqlx.Resultset;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class AutForm : Form
    {
        public AutForm()
        {
            InitializeComponent();
        }

        private void EnterBtn_Click(object sender, EventArgs e)
        {
            DB db = new DB();
            db.openConnection();
            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter();
            MySqlCommand commadn = new MySqlCommand("SELECT * FROM `user` WHERE `UserLogin` = @login AND `UserPassword` = @pass", db.GetConnection());

            commadn.Parameters.Add("@login", MySqlDbType.VarChar).Value = InputLogin.Text;
            commadn.Parameters.Add("@pass", MySqlDbType.VarChar).Value = InputPassword.Text;

            adapter.SelectCommand = commadn;
            adapter.Fill(table);

            if (table.Rows.Count > 0)
            {
                MessageBox.Show("Добро пожаловать!");
                string Role = table.Rows[0]["UserRole"].ToString();
                if (Role == "1")
                {
                    this.Hide();
                    AdminForm form = new AdminForm();
                    form.Show();
                }
            }
            else MessageBox.Show("Такого пользователя нет");
            db.CloseConnection();
        }

        private void CheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if(CheckBox.Checked == false)
            {
                InputPassword.UseSystemPasswordChar = true;
            }
            else
            {
                InputPassword.UseSystemPasswordChar = false;    
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
            RegForm regform = new RegForm();    
            regform.ShowDialog();
        }
    }
}
