﻿namespace WindowsFormsApp1
{
    partial class RegForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RegForm));
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.Logo = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.InputLogin = new System.Windows.Forms.TextBox();
            this.InputPassword = new System.Windows.Forms.TextBox();
            this.InputPantynomic = new System.Windows.Forms.TextBox();
            this.InputName = new System.Windows.Forms.TextBox();
            this.InputSurname = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.CheckBox = new System.Windows.Forms.CheckBox();
            this.EnterBtn = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.flowLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Logo)).BeginInit();
            this.SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.flowLayoutPanel1.BackColor = System.Drawing.Color.YellowGreen;
            this.flowLayoutPanel1.Controls.Add(this.Logo);
            this.flowLayoutPanel1.Controls.Add(this.label2);
            this.flowLayoutPanel1.Controls.Add(this.label3);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(12, 12);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(754, 94);
            this.flowLayoutPanel1.TabIndex = 2;
            // 
            // Logo
            // 
            this.Logo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Logo.Image = ((System.Drawing.Image)(resources.GetObject("Logo.Image")));
            this.Logo.Location = new System.Drawing.Point(3, 3);
            this.Logo.Name = "Logo";
            this.Logo.Size = new System.Drawing.Size(95, 89);
            this.Logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Logo.TabIndex = 0;
            this.Logo.TabStop = false;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 32.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(104, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(148, 60);
            this.label2.TabIndex = 1;
            this.label2.Text = "Ткани";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(258, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(17, 92);
            this.label3.TabIndex = 2;
            this.label3.Text = "|\r\n|\r\n|\r\n|";
            // 
            // InputLogin
            // 
            this.InputLogin.BackColor = System.Drawing.Color.YellowGreen;
            this.InputLogin.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.InputLogin.ForeColor = System.Drawing.Color.White;
            this.InputLogin.Location = new System.Drawing.Point(418, 159);
            this.InputLogin.Name = "InputLogin";
            this.InputLogin.Size = new System.Drawing.Size(235, 34);
            this.InputLogin.TabIndex = 3;
            this.InputLogin.Text = "Логин";
            // 
            // InputPassword
            // 
            this.InputPassword.BackColor = System.Drawing.Color.YellowGreen;
            this.InputPassword.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.InputPassword.ForeColor = System.Drawing.Color.White;
            this.InputPassword.Location = new System.Drawing.Point(418, 199);
            this.InputPassword.Name = "InputPassword";
            this.InputPassword.Size = new System.Drawing.Size(235, 34);
            this.InputPassword.TabIndex = 4;
            this.InputPassword.Text = "Пароль";
            // 
            // InputPantynomic
            // 
            this.InputPantynomic.BackColor = System.Drawing.Color.YellowGreen;
            this.InputPantynomic.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.InputPantynomic.ForeColor = System.Drawing.Color.White;
            this.InputPantynomic.Location = new System.Drawing.Point(112, 239);
            this.InputPantynomic.Name = "InputPantynomic";
            this.InputPantynomic.Size = new System.Drawing.Size(235, 34);
            this.InputPantynomic.TabIndex = 5;
            this.InputPantynomic.Text = "Отчество";
            // 
            // InputName
            // 
            this.InputName.BackColor = System.Drawing.Color.YellowGreen;
            this.InputName.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.InputName.ForeColor = System.Drawing.Color.White;
            this.InputName.Location = new System.Drawing.Point(112, 159);
            this.InputName.Name = "InputName";
            this.InputName.Size = new System.Drawing.Size(235, 34);
            this.InputName.TabIndex = 6;
            this.InputName.Text = "Имя";
            // 
            // InputSurname
            // 
            this.InputSurname.BackColor = System.Drawing.Color.YellowGreen;
            this.InputSurname.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.InputSurname.ForeColor = System.Drawing.Color.White;
            this.InputSurname.Location = new System.Drawing.Point(112, 199);
            this.InputSurname.Name = "InputSurname";
            this.InputSurname.Size = new System.Drawing.Size(235, 34);
            this.InputSurname.TabIndex = 7;
            this.InputSurname.Text = "Фамилия";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.YellowGreen;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 23.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(425, 35);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(206, 44);
            this.label1.TabIndex = 8;
            this.label1.Text = "Регистрация";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.ForestGreen;
            this.label4.Location = new System.Drawing.Point(149, 127);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(149, 23);
            this.label4.TabIndex = 9;
            this.label4.Text = "Введите свое ФИО";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.ForestGreen;
            this.label5.Location = new System.Drawing.Point(433, 127);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(196, 23);
            this.label5.TabIndex = 10;
            this.label5.Text = "Введите логин и пароль";
            // 
            // CheckBox
            // 
            this.CheckBox.AutoSize = true;
            this.CheckBox.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CheckBox.ForeColor = System.Drawing.Color.ForestGreen;
            this.CheckBox.Location = new System.Drawing.Point(116, 286);
            this.CheckBox.Name = "CheckBox";
            this.CheckBox.Size = new System.Drawing.Size(379, 19);
            this.CheckBox.TabIndex = 11;
            this.CheckBox.Text = "Я согласен на обработку персональных данных третьими лицами";
            this.CheckBox.UseVisualStyleBackColor = true;
            this.CheckBox.CheckedChanged += new System.EventHandler(this.CheckBox_CheckedChanged);
            // 
            // EnterBtn
            // 
            this.EnterBtn.BackColor = System.Drawing.Color.YellowGreen;
            this.EnterBtn.Enabled = false;
            this.EnterBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.YellowGreen;
            this.EnterBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.ForestGreen;
            this.EnterBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.EnterBtn.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.EnterBtn.ForeColor = System.Drawing.Color.White;
            this.EnterBtn.Location = new System.Drawing.Point(274, 331);
            this.EnterBtn.Name = "EnterBtn";
            this.EnterBtn.Size = new System.Drawing.Size(207, 48);
            this.EnterBtn.TabIndex = 12;
            this.EnterBtn.Text = "Зарегестрироваться";
            this.EnterBtn.UseVisualStyleBackColor = false;
            this.EnterBtn.Click += new System.EventHandler(this.EnterBtn_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Comic Sans MS", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.ForeColor = System.Drawing.Color.ForestGreen;
            this.label6.Location = new System.Drawing.Point(9, 407);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(331, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "ООО «Ткани»  - магазин по продаже тканей и фурнитуры в Кропоткине. \r\n";
            // 
            // RegForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(778, 429);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.EnterBtn);
            this.Controls.Add(this.CheckBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.InputSurname);
            this.Controls.Add(this.InputName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.InputPantynomic);
            this.Controls.Add(this.InputPassword);
            this.Controls.Add(this.InputLogin);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ForeColor = System.Drawing.Color.White;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "RegForm";
            this.Text = "Ткани";
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Logo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.PictureBox Logo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox InputLogin;
        private System.Windows.Forms.TextBox InputPassword;
        private System.Windows.Forms.TextBox InputPantynomic;
        private System.Windows.Forms.TextBox InputName;
        private System.Windows.Forms.TextBox InputSurname;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox CheckBox;
        private System.Windows.Forms.Button EnterBtn;
        private System.Windows.Forms.Label label6;
    }
}