﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Drawing.Imaging;

namespace WindowsFormsApp1
{
    public partial class AdminForm : Form
    {
        public AdminForm()
        {
            InitializeComponent();
        }

        DB db = new DB();
        DataTable table = new DataTable();

        MySqlDataAdapter adapter = new MySqlDataAdapter();
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void AdminForm_Load(object sender, EventArgs e)
        {
            MySqlCommand command = new MySqlCommand("SELECT * FROM `product`", db.GetConnection());

            adapter.SelectCommand = command;
            adapter.Fill(table);

            dataGridView1.DataSource = table;

        }

        private void RedBtn_Click(object sender, EventArgs e)
        {
            RedForm redForm = new RedForm();
            redForm.ShowDialog();
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            this.Close();
            AutForm autForm = new AutForm();
            autForm.ShowDialog();
        }

        private void RefreshBtn_Click(object sender, EventArgs e)
        {
            table.Clear();
            adapter.Fill(table);
        }

        private void DeletBtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите строку для удаления");
                return;
            }
            DialogResult result = MessageBox.Show("Вы действительно хотите удалить выбранную строку?",
            "Подтверждение",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                foreach (DataGridViewRow row in dataGridView1.SelectedRows)
                {
                    dataGridView1.Rows.Remove(row);
                }
                MySqlCommandBuilder cd = new MySqlCommandBuilder(adapter);
                adapter.Update(table);
                table.Clear();
                adapter.Fill(table);

            }
        }
    }
}
