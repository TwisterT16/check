﻿namespace Flags
{
    partial class MainMenu
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainMenu));
            this.CloseBtn = new System.Windows.Forms.Button();
            this.Sign = new System.Windows.Forms.Label();
            this.TextChange = new System.Windows.Forms.Button();
            this.Input = new System.Windows.Forms.TextBox();
            this.Side = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.Muzz = new System.Windows.Forms.Button();
            this.RanColor = new System.Windows.Forms.Button();
            this.RightMove = new System.Windows.Forms.Button();
            this.BritishFlag = new System.Windows.Forms.Button();
            this.Side.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // CloseBtn
            // 
            this.CloseBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.CloseBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.CloseBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CloseBtn.Location = new System.Drawing.Point(767, 2);
            this.CloseBtn.Name = "CloseBtn";
            this.CloseBtn.Size = new System.Drawing.Size(30, 29);
            this.CloseBtn.TabIndex = 0;
            this.CloseBtn.Text = "X";
            this.CloseBtn.UseVisualStyleBackColor = false;
            this.CloseBtn.Click += new System.EventHandler(this.CloseBtn_Click);
            // 
            // Sign
            // 
            this.Sign.AutoSize = true;
            this.Sign.BackColor = System.Drawing.Color.White;
            this.Sign.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Sign.Location = new System.Drawing.Point(159, 15);
            this.Sign.Name = "Sign";
            this.Sign.Size = new System.Drawing.Size(151, 25);
            this.Sign.TabIndex = 2;
            this.Sign.Text = "Флаг России";
            // 
            // TextChange
            // 
            this.TextChange.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TextChange.Location = new System.Drawing.Point(520, 66);
            this.TextChange.Name = "TextChange";
            this.TextChange.Size = new System.Drawing.Size(211, 45);
            this.TextChange.TabIndex = 3;
            this.TextChange.Text = "Изменить надпись";
            this.TextChange.UseVisualStyleBackColor = true;
            this.TextChange.Click += new System.EventHandler(this.TextChange_Click);
            // 
            // Input
            // 
            this.Input.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Input.Location = new System.Drawing.Point(155, 12);
            this.Input.Name = "Input";
            this.Input.Size = new System.Drawing.Size(155, 31);
            this.Input.TabIndex = 4;
            this.Input.Visible = false;
            // 
            // Side
            // 
            this.Side.BackColor = System.Drawing.Color.Silver;
            this.Side.Controls.Add(this.pictureBox1);
            this.Side.Location = new System.Drawing.Point(34, 59);
            this.Side.Name = "Side";
            this.Side.Size = new System.Drawing.Size(408, 379);
            this.Side.TabIndex = 5;
            this.Side.Paint += new System.Windows.Forms.PaintEventHandler(this.Side_Paint);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(107, 124);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(197, 129);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // Muzz
            // 
            this.Muzz.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Muzz.Location = new System.Drawing.Point(520, 126);
            this.Muzz.Name = "Muzz";
            this.Muzz.Size = new System.Drawing.Size(211, 45);
            this.Muzz.TabIndex = 7;
            this.Muzz.Text = "Мозайка";
            this.Muzz.UseVisualStyleBackColor = true;
            this.Muzz.Click += new System.EventHandler(this.Muzz_Click);
            // 
            // RanColor
            // 
            this.RanColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RanColor.Location = new System.Drawing.Point(520, 189);
            this.RanColor.Name = "RanColor";
            this.RanColor.Size = new System.Drawing.Size(211, 45);
            this.RanColor.TabIndex = 8;
            this.RanColor.Text = "Изменить цвет фона";
            this.RanColor.UseVisualStyleBackColor = true;
            this.RanColor.Click += new System.EventHandler(this.RanColor_Click);
            // 
            // RightMove
            // 
            this.RightMove.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RightMove.Location = new System.Drawing.Point(520, 250);
            this.RightMove.Name = "RightMove";
            this.RightMove.Size = new System.Drawing.Size(211, 56);
            this.RightMove.TabIndex = 9;
            this.RightMove.Text = "Сдвинуть флаг вправо";
            this.RightMove.UseVisualStyleBackColor = true;
            this.RightMove.Click += new System.EventHandler(this.RightMove_Click);
            // 
            // BritishFlag
            // 
            this.BritishFlag.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BritishFlag.Location = new System.Drawing.Point(520, 320);
            this.BritishFlag.Name = "BritishFlag";
            this.BritishFlag.Size = new System.Drawing.Size(211, 56);
            this.BritishFlag.TabIndex = 10;
            this.BritishFlag.Text = "Смена флага и надписи";
            this.BritishFlag.UseVisualStyleBackColor = true;
            this.BritishFlag.Click += new System.EventHandler(this.BritishFlag_Click);
            // 
            // MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BritishFlag);
            this.Controls.Add(this.RightMove);
            this.Controls.Add(this.RanColor);
            this.Controls.Add(this.Muzz);
            this.Controls.Add(this.Side);
            this.Controls.Add(this.Input);
            this.Controls.Add(this.TextChange);
            this.Controls.Add(this.Sign);
            this.Controls.Add(this.CloseBtn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MainMenu";
            this.Text = "Form1";
            this.Side.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button CloseBtn;
        private System.Windows.Forms.Label Sign;
        private System.Windows.Forms.Button TextChange;
        private System.Windows.Forms.TextBox Input;
        private System.Windows.Forms.Panel Side;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Button Muzz;
        private System.Windows.Forms.Button RanColor;
        private System.Windows.Forms.Button RightMove;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button BritishFlag;
    }
}

