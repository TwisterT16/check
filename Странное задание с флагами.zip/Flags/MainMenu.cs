﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flags
{
    public partial class MainMenu : Form
    {
        public MainMenu()
        {
            InitializeComponent();
        }

        private void TextChange_Click(object sender, EventArgs e)
        {
            Input.Visible = true;
            if (Input.Text == "")
            {
                Sign.Text = Input.Text;
            }
            else
            {
                Sign.Text = Input.Text;
                Input.Visible = false;
                Input.Text = "";
            }

        }

        private void CloseBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Muzz_Click(object sender, EventArgs e)
        {
            Side.BackgroundImage = Image.FromFile("E:/долги/Flags/images.png");
            Side.BackgroundImageLayout = ImageLayout.Tile;
            pictureBox1.Visible = false;
        }

        private void RanColor_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            this.BackColor = Color.FromArgb(r.Next(200), r.Next(200), r.Next(200));  
        }

        private void RightMove_Click(object sender, EventArgs e)
        {
            pictureBox1.Location = new Point(pictureBox1.Location.X + 20);
            pictureBox1.Visible = true;

        }

        private void Side_Paint(object sender, PaintEventArgs e)
        {

        }

        private void BritishFlag_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile("E:/долги/Flags/flag-velikobritanii.png");
            Sign.Text = "Флаг Великобритании";
            pictureBox1.Visible = true;
        }
    }
}
