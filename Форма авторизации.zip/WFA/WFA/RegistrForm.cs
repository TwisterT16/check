﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;
using System.IO;
using static System.Drawing.Image;

namespace WFA
{
    public partial class RegistrForm : Form
    {
        public RegistrForm()
        {
            InitializeComponent();
            NameInput.Text = "Введите имя";
            SurenameInput.Text = "Введите фамилию";
            LoginInput.Text = "Введите логин";
            PasswordInput.Text = "Введите пароль";
        }

        private void NameInput_Click(object sender, EventArgs e)
        {
            NameInput.Clear();
        }

        private void SurenameInput_Click(object sender, EventArgs e)
        {
            SurenameInput.Clear();
        }

        private void LoginInput_Click(object sender, EventArgs e)
        {
            LoginInput.Clear();
        }

        private void PasswordInput_Click(object sender, EventArgs e)
        {
            PasswordInput.Clear();
        }

        private void CloseBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        Point LastPoin;

        private void RegistrForm_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - LastPoin.X;
                this.Top += e.Y - LastPoin.Y;
            }
        }

        private void RegistrForm_MouseDown(object sender, MouseEventArgs e)
        {
            LastPoin = new Point(e.X, e.Y); 
        }

        private void NameInput_TextChanged(object sender, EventArgs e)
        {

        }

        private void NameInput_Enter(object sender, EventArgs e)
        {
            NameInput.Text = "";
        }

        private void SurenameInput_Enter(object sender, EventArgs e)
        {
            SurenameInput.Text = "";
        }

        private void LoginInput_Enter(object sender, EventArgs e)
        {
            LoginInput.Text = "";
        }

        private void PasswordInput_Enter(object sender, EventArgs e)
        {
            PasswordInput.Text = "";
        }

        private void RegBtn_Click(object sender, EventArgs e)
        {
            if (LoginInput.Text == "Введите логин" || LoginInput.Text == "" || PasswordInput.Text == "Введите пароль" || PasswordInput.Text == "" || NameInput.Text == "Введите имя" || NameInput.Text == "" || SurenameInput.Text == "Введите фамилию" || SurenameInput.Text == "")
            {
                MessageBox.Show("Ошибка ввода данных");
                return;
            }
            if(UserCheck())
                return;

            Bitmap bitmap; /*= (Bitmap)Image.FromFile(pictureBox1.Image);*/
            bitmap = new Bitmap(pictureBox1.Image);
            

            DB db = new DB();   
            MySqlCommand command = new MySqlCommand("INSERT INTO `users`(`login`, `pass`, `username`, `usersurename`, `userimage`) VALUES (@login, @pass, @name, @surename, @image);", db.GetConnection());
            command.Parameters.Add("@login", MySqlDbType.VarChar).Value = LoginInput.Text;
            command.Parameters.Add("@pass", MySqlDbType.VarChar).Value = PasswordInput.Text;
            command.Parameters.Add("@name", MySqlDbType.VarChar).Value = NameInput.Text;
            command.Parameters.Add("@surename", MySqlDbType.VarChar).Value = SurenameInput.Text;
            command.Parameters.Add("@image", MySqlDbType.Blob).Value = pictureBox1.Image;

            db.openConnection();

            if (command.ExecuteNonQuery() == 1)
                MessageBox.Show("Аккаунт был создан.");
            else
                MessageBox.Show("Аккаунт не был создан!");
            db.closeConnection();
        }

        public Boolean UserCheck()
        {
            DB db = new DB();   
            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter();

            MySqlCommand command = new MySqlCommand("SELECT * FROM `users` WHERE `login` = @ul", db.GetConnection());
            command.Parameters.Add("@ul", MySqlDbType.VarChar).Value = LoginInput.Text;

            adapter.SelectCommand = command;
            adapter.Fill(table);
            if (table.Rows.Count > 0)
            { 
                MessageBox.Show("Пользователь с таким логином уже существует");
                return true;
            }
            else return false;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files(*.JPG;*.GIF;*.PNG)|*.JPG;*.GIF;*.PNG";
            Bitmap image;
            if (openFileDialog.ShowDialog() == DialogResult.OK) 
            {
                try
                {
                    image = new Bitmap(openFileDialog.FileName);
                    //вместо pictureBox1 укажите pictureBox, в который нужно загрузить изображение 
                    pictureBox1.Image = image;
                    pictureBox1.Invalidate();
                    pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
                }
                catch
                {
                    DialogResult rezult = MessageBox.Show("Невозможно открыть выбранный файл",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

        }
    }
}
