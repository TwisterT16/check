﻿namespace WFA
{
    partial class RegistrForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RegistrForm));
            this.Side = new System.Windows.Forms.Panel();
            this.RegBtn = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.PasswordInput = new System.Windows.Forms.TextBox();
            this.LoginInput = new System.Windows.Forms.TextBox();
            this.SurenameInput = new System.Windows.Forms.TextBox();
            this.NameInput = new System.Windows.Forms.TextBox();
            this.TopSide = new System.Windows.Forms.Panel();
            this.CloseBtn = new System.Windows.Forms.Button();
            this.Sign = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Side.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.TopSide.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Side
            // 
            this.Side.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Side.Controls.Add(this.panel1);
            this.Side.Controls.Add(this.RegBtn);
            this.Side.Controls.Add(this.PasswordInput);
            this.Side.Controls.Add(this.LoginInput);
            this.Side.Controls.Add(this.SurenameInput);
            this.Side.Controls.Add(this.NameInput);
            this.Side.Controls.Add(this.TopSide);
            this.Side.Location = new System.Drawing.Point(0, 0);
            this.Side.Name = "Side";
            this.Side.Size = new System.Drawing.Size(352, 452);
            this.Side.TabIndex = 0;
            // 
            // RegBtn
            // 
            this.RegBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.RegBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RegBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RegBtn.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.RegBtn.Location = new System.Drawing.Point(88, 378);
            this.RegBtn.Name = "RegBtn";
            this.RegBtn.Size = new System.Drawing.Size(187, 48);
            this.RegBtn.TabIndex = 6;
            this.RegBtn.Text = "Зарегестрироваться";
            this.RegBtn.UseVisualStyleBackColor = false;
            this.RegBtn.Click += new System.EventHandler(this.RegBtn_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(69, 68);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // PasswordInput
            // 
            this.PasswordInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.PasswordInput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PasswordInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.PasswordInput.ForeColor = System.Drawing.SystemColors.Info;
            this.PasswordInput.Location = new System.Drawing.Point(70, 327);
            this.PasswordInput.Name = "PasswordInput";
            this.PasswordInput.Size = new System.Drawing.Size(223, 29);
            this.PasswordInput.TabIndex = 4;
            this.PasswordInput.Text = "Password";
            this.PasswordInput.Click += new System.EventHandler(this.PasswordInput_Click);
            this.PasswordInput.Enter += new System.EventHandler(this.PasswordInput_Enter);
            // 
            // LoginInput
            // 
            this.LoginInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.LoginInput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LoginInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LoginInput.ForeColor = System.Drawing.SystemColors.Info;
            this.LoginInput.Location = new System.Drawing.Point(70, 278);
            this.LoginInput.Name = "LoginInput";
            this.LoginInput.Size = new System.Drawing.Size(223, 29);
            this.LoginInput.TabIndex = 3;
            this.LoginInput.Text = "Login";
            this.LoginInput.Click += new System.EventHandler(this.LoginInput_Click);
            this.LoginInput.Enter += new System.EventHandler(this.LoginInput_Enter);
            // 
            // SurenameInput
            // 
            this.SurenameInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.SurenameInput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SurenameInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SurenameInput.ForeColor = System.Drawing.SystemColors.Info;
            this.SurenameInput.Location = new System.Drawing.Point(70, 229);
            this.SurenameInput.Name = "SurenameInput";
            this.SurenameInput.Size = new System.Drawing.Size(223, 29);
            this.SurenameInput.TabIndex = 2;
            this.SurenameInput.Text = "Surename";
            this.SurenameInput.Click += new System.EventHandler(this.SurenameInput_Click);
            this.SurenameInput.Enter += new System.EventHandler(this.SurenameInput_Enter);
            // 
            // NameInput
            // 
            this.NameInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.NameInput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.NameInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NameInput.ForeColor = System.Drawing.SystemColors.Info;
            this.NameInput.Location = new System.Drawing.Point(69, 180);
            this.NameInput.Name = "NameInput";
            this.NameInput.Size = new System.Drawing.Size(223, 29);
            this.NameInput.TabIndex = 1;
            this.NameInput.Text = "Name";
            this.NameInput.Click += new System.EventHandler(this.NameInput_Click);
            this.NameInput.TextChanged += new System.EventHandler(this.NameInput_TextChanged);
            this.NameInput.Enter += new System.EventHandler(this.NameInput_Enter);
            // 
            // TopSide
            // 
            this.TopSide.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.TopSide.Controls.Add(this.CloseBtn);
            this.TopSide.Controls.Add(this.Sign);
            this.TopSide.Location = new System.Drawing.Point(0, -1);
            this.TopSide.Name = "TopSide";
            this.TopSide.Size = new System.Drawing.Size(352, 100);
            this.TopSide.TabIndex = 0;
            // 
            // CloseBtn
            // 
            this.CloseBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.CloseBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.CloseBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CloseBtn.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.CloseBtn.Location = new System.Drawing.Point(320, 0);
            this.CloseBtn.Name = "CloseBtn";
            this.CloseBtn.Size = new System.Drawing.Size(32, 30);
            this.CloseBtn.TabIndex = 1;
            this.CloseBtn.Text = "X";
            this.CloseBtn.UseVisualStyleBackColor = false;
            this.CloseBtn.Click += new System.EventHandler(this.CloseBtn_Click);
            // 
            // Sign
            // 
            this.Sign.AutoSize = true;
            this.Sign.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Sign.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Sign.Location = new System.Drawing.Point(61, 29);
            this.Sign.Name = "Sign";
            this.Sign.Size = new System.Drawing.Size(239, 42);
            this.Sign.TabIndex = 0;
            this.Sign.Text = "Регистрация";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(141, 105);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(75, 71);
            this.panel1.TabIndex = 7;
            // 
            // RegistrForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(352, 450);
            this.Controls.Add(this.Side);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "RegistrForm";
            this.Text = "RegistrForm";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.RegistrForm_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.RegistrForm_MouseMove);
            this.Side.ResumeLayout(false);
            this.Side.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.TopSide.ResumeLayout(false);
            this.TopSide.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Side;
        private System.Windows.Forms.Panel TopSide;
        private System.Windows.Forms.Label Sign;
        private System.Windows.Forms.TextBox PasswordInput;
        private System.Windows.Forms.TextBox LoginInput;
        private System.Windows.Forms.TextBox SurenameInput;
        private System.Windows.Forms.TextBox NameInput;
        private System.Windows.Forms.Button RegBtn;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button CloseBtn;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Panel panel1;
    }
}